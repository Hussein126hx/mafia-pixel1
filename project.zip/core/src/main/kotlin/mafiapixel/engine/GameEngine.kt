package mafiapixel.engine

/**
 * GameEngine has ZERO knowledge of UI or transport (no Android, no networking imports).
 * It is pure state + rules. NetworkManager (server side) wraps one GameEngine per room
 * and is the only thing that knows about sockets/clients.
 *
 * Usage: call the phase-transition functions in order; each returns the events that
 * occurred so the caller (NetworkManager) can broadcast filtered views to clients.
 */
class GameEngine(
    private val settings: GameSettings,
    private val rng: (Int) -> Int = { kotlin.random.Random.nextInt(it) }
) {
    var phase: GamePhase = GamePhase.LOBBY
        private set

    private val players = linkedMapOf<PlayerId, Player>()
    private var roster: Map<PlayerId, Role> = emptyMap()
    private var nightNumber = 0
    private var dayNumber = 0

    private val roleManager = RoleManager()
    private val nightSystem = NightSystem()
    private val votingSystem = VotingSystem()
    private val victorySystem = VictorySystem()

    private val pendingNightActions = mutableListOf<NightAction>()
    private val history = mutableListOf<GameEvent>()

    // ---------- LOBBY ----------

    fun addPlayer(id: PlayerId, name: String): GameEvent {
        check(phase == GamePhase.LOBBY) { "Cannot join after game has started" }
        players[id] = Player(id, name)
        return record(GameEvent.PlayerJoined(id, name))
    }

    fun removePlayer(id: PlayerId): GameEvent {
        if (phase == GamePhase.LOBBY) players.remove(id)
        else players[id]?.isConnected = false
        return record(GameEvent.PlayerLeft(id))
    }

    fun canStart(): Boolean = phase == GamePhase.LOBBY && players.size >= settings.minPlayers && players.size <= settings.maxPlayers

    // ---------- ROLE_DISTRIBUTION / ROLE_REVEAL ----------

    /** Returns per-player RoleAssigned events — caller must send each ONLY to that player. */
    fun startGame(): List<GameEvent> {
        check(canStart()) { "Not enough/too many players, or already started" }
        phase = GamePhase.ROLE_DISTRIBUTION
        roster = roleManager.distribute(players.values.toList(), settings, rng)
        roster.forEach { (id, role) -> players[id]?.role = role }
        val events = mutableListOf<GameEvent>(record(GameEvent.GameStarted))
        roster.forEach { (id, role) -> events += record(GameEvent.RoleAssigned(id, role)) }
        phase = GamePhase.ROLE_REVEAL
        return events
    }

    // ---------- NIGHT ----------

    fun beginNight(): GameEvent {
        phase = GamePhase.NIGHT
        nightNumber++
        pendingNightActions.clear()
        return record(GameEvent.NightStarted(nightNumber))
    }

    /** Submitting a new action for the same actor replaces their previous one (last submit wins). */
    fun submitNightAction(actorId: PlayerId, targetId: PlayerId): Boolean {
        val role = players[actorId]?.role ?: return false
        if (!players[actorId]!!.isAlive || role.nightAction == NightActionType.NONE) return false
        pendingNightActions.removeAll { it.actorId == actorId }
        pendingNightActions += NightAction(actorId, targetId, role.nightAction)
        return true
    }

    /** Resolves the night, returns events (some private — filter per-recipient before broadcasting). */
    fun resolveNight(): List<GameEvent> {
        phase = GamePhase.NIGHT_RESOLUTION
        val events = nightSystem.resolve(roster, players, pendingNightActions).map { record(it) }
        phase = GamePhase.DAWN
        return events
    }

    // ---------- DAY / DISCUSSION ----------

    fun beginDay(): GameEvent {
        phase = GamePhase.DISCUSSION
        dayNumber++
        record(GameEvent.DayStarted(dayNumber))
        return record(GameEvent.DiscussionStarted)
    }

    // ---------- VOTING ----------

    fun beginVoting(): GameEvent {
        phase = GamePhase.VOTING
        votingSystem.reset()
        return record(GameEvent.VotingStarted)
    }

    fun castVote(voterId: PlayerId, targetId: PlayerId?): GameEvent? {
        if (phase != GamePhase.VOTING) return null
        if (players[voterId]?.isAlive != true) return null
        return record(votingSystem.castVote(voterId, targetId))
    }

    fun closeVoting(): List<GameEvent> {
        phase = GamePhase.VOTE_RESULT
        val alive = players.values.filter { it.isAlive }.map { it.id }.toSet()
        val closed = record(votingSystem.close(alive, rng)) as GameEvent.VotingClosed
        val events = mutableListOf<GameEvent>(closed)

        phase = GamePhase.ELIMINATION
        closed.eliminatedId?.let { id ->
            players[id]?.state = PlayerConnState.DEAD
            events += record(
                GameEvent.PlayerEliminated(
                    id, EliminationCause.VOTE,
                    revealedRole = if (settings.revealRoleOnElimination) roster[id] else null
                )
            )
        }
        return events
    }

    // ---------- WIN CHECK ----------

    /** Returns the winner if the game is over, else null (meaning: proceed to next night). */
    fun checkWinCondition(): GameEvent.GameEnded? {
        phase = GamePhase.WIN_CHECK
        val winner = victorySystem.checkVictory(players, roster)
        if (winner == null) return null
        phase = GamePhase.GAME_END
        return record(GameEvent.GameEnded(winner, roster)) as GameEvent.GameEnded
    }

    // ---------- RECONNECTION ----------

    fun handleReconnect(id: PlayerId): GameEvent? {
        val p = players[id] ?: return null
        p.isConnected = true
        if (p.state == PlayerConnState.DISCONNECTED) p.state = PlayerConnState.RECONNECTED
        return record(GameEvent.PlayerReconnected(id))
    }

    // ---------- VIEWS (per-player filtered state — never leak secret info) ----------

    fun publicPlayerList(): List<Pair<PlayerId, PlayerConnState>> =
        players.values.map { it.id to it.state }

    fun roleOf(playerId: PlayerId): Role? = players[playerId]?.role

    fun mafiaTeammatesOf(playerId: PlayerId): List<PlayerId> = roleManager.mafiaTeammatesOf(playerId, roster)

    fun eventHistory(): List<GameEvent> = history.toList()

    private fun record(event: GameEvent): GameEvent {
        history += event
        return event
    }
}
