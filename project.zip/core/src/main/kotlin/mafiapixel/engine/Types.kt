package mafiapixel.engine

typealias PlayerId = String

enum class PlayerConnState { ALIVE, DEAD, SPECTATOR, DISCONNECTED, RECONNECTED }

data class Player(
    val id: PlayerId,
    val name: String,
    var role: Role? = null,       // assigned at ROLE_DISTRIBUTION
    var state: PlayerConnState = PlayerConnState.ALIVE,
    var isConnected: Boolean = true
) {
    val isAlive get() = state == PlayerConnState.ALIVE || state == PlayerConnState.RECONNECTED
}

enum class GamePhase {
    LOBBY,
    ROLE_DISTRIBUTION,
    ROLE_REVEAL,
    NIGHT,
    NIGHT_RESOLUTION,
    DAWN,
    DISCUSSION,
    VOTING,
    VOTE_RESULT,
    ELIMINATION,
    WIN_CHECK,
    GAME_END
}

data class GameSettings(
    val minPlayers: Int = 5,
    val maxPlayers: Int = 50,
    val discussionSeconds: Int = 120,
    val votingSeconds: Int = 45,
    val revealRoleOnElimination: Boolean = true,
    val secretVoting: Boolean = false,
    val allowAbstain: Boolean = true,
    val customRolePool: List<Role>? = null // host override; null = dynamic tiers
)

/**
 * Every meaningful thing that happens is an event. Events are the single
 * source of truth for: (a) what gets broadcast to clients, (b) what's
 * filtered per-player visibility, (c) the public event history log.
 */
sealed class GameEvent {
    data class PlayerJoined(val playerId: PlayerId, val name: String) : GameEvent()
    data class PlayerLeft(val playerId: PlayerId) : GameEvent()
    data class PlayerDisconnected(val playerId: PlayerId) : GameEvent()
    data class PlayerReconnected(val playerId: PlayerId) : GameEvent()
    object GameStarted : GameEvent()
    data class RoleAssigned(val playerId: PlayerId, val role: Role) : GameEvent() // private, never broadcast raw
    data class NightStarted(val nightNumber: Int) : GameEvent()
    data class PlayerTargeted(val actorId: PlayerId, val targetId: PlayerId, val action: NightActionType) : GameEvent() // private
    data class PlayerProtected(val targetId: PlayerId) : GameEvent() // private, revealed only to doctor
    data class InvestigationResult(val investigatorId: PlayerId, val targetId: PlayerId, val revealedTeam: Team) : GameEvent() // private
    data class PlayerEliminated(val playerId: PlayerId, val cause: EliminationCause, val revealedRole: Role?) : GameEvent() // public
    data class DayStarted(val dayNumber: Int) : GameEvent()
    object DiscussionStarted : GameEvent()
    object VotingStarted : GameEvent()
    data class VoteCast(val voterId: PlayerId, val targetId: PlayerId?) : GameEvent() // targetId null = abstain
    data class VotingClosed(val tally: Map<PlayerId, Int>, val eliminatedId: PlayerId?) : GameEvent() // public
    data class GameEnded(val winningTeam: Team?, val roster: Map<PlayerId, Role>) : GameEvent()
}

enum class EliminationCause { MAFIA_KILL, VOTE, NEUTRAL_ACTION, OTHER }
