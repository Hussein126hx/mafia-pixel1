package mafiapixel.android

import mafiapixel.engine.*

/** Runs a full headless 7-player match through the real GameEngine and returns a readable log. */
object Simulation {
    fun run(): List<String> {
        val e = GameEngine(GameSettings())
        val log = mutableListOf<String>()
        for (i in 1..7) e.addPlayer("p$i", "P$i")
        e.startGame()
        val mafia = (1..7).filter { e.roleOf("p$it")?.team == Team.MAFIA }
        log += "Match start: 7 players, mafia = ${mafia.joinToString { "P$it" }}"

        fun alive() = e.publicPlayerList().filter { it.second == PlayerConnState.ALIVE }.map { it.first }
        fun name(id: String) = id.uppercase()

        for (round in 1..15) {
            e.beginNight()
            val a = alive()
            for (id in a) {
                val role = e.roleOf(id) ?: continue
                if (role.nightAction == NightActionType.NONE) continue
                val t = a.filter { it != id }.randomOrNull() ?: continue
                e.submitNightAction(id, t)
            }
            for (ev in e.resolveNight()) {
                if (ev is GameEvent.PlayerEliminated) log += "Night $round: ${name(ev.playerId)} was killed"
            }
            e.checkWinCondition()?.let { log += "WINNER: ${it.winningTeam}"; return log }

            e.beginDay(); e.beginVoting()
            val a2 = alive()
            for (v in a2) e.castVote(v, a2.filter { it != v }.randomOrNull())
            for (ev in e.closeVoting()) {
                if (ev is GameEvent.PlayerEliminated) {
                    log += "Day $round: ${name(ev.playerId)} voted out (${ev.revealedRole?.displayName})"
                }
            }
            e.checkWinCondition()?.let { log += "WINNER: ${it.winningTeam}"; return log }
        }
        log += "No winner after 15 rounds"
        return log
    }
}
