package mafiapixel.engine

/**
 * A victory condition is just a predicate over the current alive roster.
 * New conditions (e.g. a Neutral role that wins solo) are added by appending
 * to `conditions` — nothing else in the engine needs to change.
 */
fun interface VictoryCondition {
    /** Returns the winning Team if this condition is met, else null. */
    fun check(aliveRoster: Map<PlayerId, Role>): Team?
}

class VictorySystem {

    private val conditions = mutableListOf<VictoryCondition>(
        // Mafia wins when they out-number or equal the rest of the town+neutral alive pool.
        VictoryCondition { alive ->
            val mafia = alive.values.count { it.team == Team.MAFIA }
            val others = alive.size - mafia
            if (mafia > 0 && mafia >= others) Team.MAFIA else null
        },
        // Town wins when no Mafia remain alive.
        VictoryCondition { alive ->
            val mafia = alive.values.count { it.team == Team.MAFIA }
            if (mafia == 0 && alive.isNotEmpty()) Team.TOWN else null
        }
    )

    fun registerCondition(condition: VictoryCondition) {
        conditions += condition
    }

    /** Checked after every elimination (night or vote). Returns the first matching winner, or null if the game continues. */
    fun checkVictory(players: Map<PlayerId, Player>, roster: Map<PlayerId, Role>): Team? {
        val aliveRoster = players.filterValues { it.isAlive }.keys
            .mapNotNull { id -> roster[id]?.let { id to it } }
            .toMap()
        for (c in conditions) {
            val winner = c.check(aliveRoster)
            if (winner != null) return winner
        }
        return null
    }
}
