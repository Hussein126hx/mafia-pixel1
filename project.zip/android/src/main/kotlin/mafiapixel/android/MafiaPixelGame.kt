package mafiapixel.android

import com.badlogic.gdx.ApplicationAdapter
import com.badlogic.gdx.Gdx
import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.GL20
import com.badlogic.gdx.graphics.Texture
import com.badlogic.gdx.graphics.g2d.BitmapFont
import com.badlogic.gdx.graphics.g2d.GlyphLayout
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.graphics.glutils.ShapeRenderer
import com.badlogic.gdx.utils.viewport.FitViewport
import kotlin.math.sin
import kotlin.random.Random

/** Pixel-look night city (virtual 320x180 resolution) + tap to run a real engine match. */
class MafiaPixelGame : ApplicationAdapter() {
    private val vw = 320f
    private val vh = 180f
    private val groundY = 22f

    private lateinit var viewport: FitViewport
    private lateinit var shapes: ShapeRenderer
    private lateinit var batch: SpriteBatch
    private lateinit var font: BitmapFont
    private val layout = GlyphLayout()
    private var time = 0f
    private val rng = Random(7)

    private val dropX = FloatArray(140)
    private val dropY = FloatArray(140)
    private val dropV = FloatArray(140)

    private class Building(val x: Float, val w: Float, val h: Float)
    private lateinit var layers: List<List<Building>>
    private val layerColor = listOf(Color(0.10f, 0.10f, 0.14f, 1f), Color(0.05f, 0.05f, 0.08f, 1f))
    private val layerDrift = floatArrayOf(3f, 8f)

    private val red = Color(0.62f, 0.07f, 0.09f, 1f)
    private val gold = Color(0.85f, 0.65f, 0.20f, 1f)
    private var log: List<String> = emptyList()

    override fun create() {
        viewport = FitViewport(vw, vh)
        shapes = ShapeRenderer()
        batch = SpriteBatch()
        font = BitmapFont()
        font.region.texture.setFilter(Texture.TextureFilter.Nearest, Texture.TextureFilter.Nearest)
        layers = listOf(makeLayer(35f, 80f, 14f, 30f), makeLayer(50f, 105f, 20f, 40f))
        for (i in dropX.indices) {
            dropX[i] = rng.nextFloat() * (vw + 40f)
            dropY[i] = rng.nextFloat() * vh
            dropV[i] = 120f + rng.nextFloat() * 80f
        }
    }

    private fun makeLayer(minH: Float, maxH: Float, minW: Float, maxW: Float): List<Building> {
        val list = mutableListOf<Building>()
        var x = -20f
        while (x < vw + 20f) {
            val w = minW + rng.nextFloat() * (maxW - minW)
            val h = minH + rng.nextFloat() * (maxH - minH)
            list += Building(x, w, h)
            x += w + rng.nextFloat() * 3f
        }
        return list
    }

    override fun resize(width: Int, height: Int) {
        viewport.update(width, height, true)
    }

    override fun render() {
        val dt = Gdx.graphics.deltaTime.coerceAtMost(0.05f)
        time += dt
        if (Gdx.input.justTouched()) log = Simulation.run()

        for (i in dropX.indices) {
            dropY[i] -= dropV[i] * dt
            dropX[i] -= 25f * dt
            if (dropY[i] < 0f) {
                dropY[i] = vh + rng.nextFloat() * 20f
                dropX[i] = rng.nextFloat() * (vw + 40f)
            }
        }

        Gdx.gl.glClearColor(0.02f, 0.02f, 0.04f, 1f)
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT)
        Gdx.gl.glEnable(GL20.GL_BLEND)
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA)
        viewport.apply()
        shapes.projectionMatrix = viewport.camera.combined
        batch.projectionMatrix = viewport.camera.combined

        shapes.begin(ShapeRenderer.ShapeType.Filled)
        // moon + glow
        shapes.setColor(0.85f, 0.85f, 0.75f, 0.10f); shapes.circle(255f, 145f, 26f, 24)
        shapes.setColor(0.85f, 0.85f, 0.75f, 0.18f); shapes.circle(255f, 145f, 19f, 24)
        shapes.setColor(0.92f, 0.92f, 0.85f, 1f); shapes.circle(255f, 145f, 13f, 24)
        // buildings (parallax drift)
        for ((li, layer) in layers.withIndex()) {
            val drift = sin(time * 0.15f) * layerDrift[li]
            shapes.color = layerColor[li]
            for (b in layer) shapes.rect(b.x + drift, groundY, b.w, b.h)
            if (li == 1) {
                for ((bi, b) in layer.withIndex()) {
                    var wy = groundY + 6f
                    while (wy < groundY + b.h - 6f) {
                        var wx = b.x + 4f
                        while (wx < b.x + b.w - 5f) {
                            val seed = bi * 31 + (wx * 3).toInt() * 17 + (wy * 5).toInt() * 13
                            val off = ((seed + (time * 0.6f).toInt()) % 19 == 0)
                            if (seed % 4 != 0 && !off) {
                                shapes.setColor(gold.r, gold.g, gold.b, 0.85f)
                                shapes.rect(wx + drift, wy, 3f, 4f)
                            }
                            wx += 7f
                        }
                        wy += 9f
                    }
                }
            }
        }
        // street + streetlights
        shapes.setColor(0.03f, 0.03f, 0.04f, 1f); shapes.rect(0f, 0f, vw, groundY)
        var lx = 30f
        while (lx < vw) {
            shapes.setColor(0.12f, 0.12f, 0.14f, 1f); shapes.rect(lx, groundY, 2f, 26f)
            val flick = 0.5f + 0.2f * sin(time * 7f + lx)
            shapes.setColor(gold.r, gold.g, gold.b, 0.15f * flick + 0.05f); shapes.circle(lx + 1f, groundY + 27f, 14f, 16)
            shapes.setColor(gold.r, gold.g, gold.b, 0.9f); shapes.rect(lx - 2f, groundY + 26f, 6f, 3f)
            lx += 85f
        }
        // fog
        for (i in 0 until 3) {
            val fx = ((time * (6f + i * 3f) + i * 130f) % (vw + 160f)) - 120f
            shapes.setColor(0.6f, 0.6f, 0.7f, 0.05f)
            shapes.rect(fx, groundY + i * 6f, 140f, 16f)
        }
        // rain
        shapes.setColor(0.6f, 0.65f, 0.8f, 0.55f)
        for (i in dropX.indices) shapes.rect(dropX[i], dropY[i], 1f, 4f)
        shapes.end()

        batch.begin()
        font.data.setScale(1.7f)
        font.color = red
        layout.setText(font, "MAFIA PIXEL")
        font.draw(batch, "MAFIA PIXEL", (vw - layout.width) / 2f, vh - 14f)
        font.data.setScale(0.6f)
        if (log.isEmpty()) {
            font.color = if ((time * 1.5f).toInt() % 2 == 0) gold else Color.WHITE
            layout.setText(font, "TAP TO RUN A TEST MATCH")
            font.draw(batch, "TAP TO RUN A TEST MATCH", (vw - layout.width) / 2f, 60f)
        } else {
            font.color = Color.WHITE
            var y = vh - 44f
            for (line in log.takeLast(9)) { font.draw(batch, line, 8f, y); y -= 11f }
        }
        batch.end()
    }

    override fun dispose() {
        shapes.dispose(); batch.dispose(); font.dispose()
    }
}
