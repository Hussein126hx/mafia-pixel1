package mafiapixel.server

import mafiapixel.engine.*

/**
 * Wraps one GameEngine + its connected sockets. This is the ONLY layer that
 * knows about networking; GameEngine itself stays pure logic (see core module).
 *
 * The same Room class runs in two contexts with zero code changes:
 *  - ONLINE:       hosted in the cloud, players connect over the internet.
 *  - LOCAL/HOTSPOT: hosted inside the Android host app's own embedded Ktor
 *                    server, players on the same Wi-Fi/hotspot connect to the
 *                    host device's local IP instead of a cloud domain.
 */
class Room(val code: String, private val settings: GameSettings) {

    val engine = GameEngine(settings)
    private val connections = mutableMapOf<PlayerId, PlayerConnection>()

    fun join(connection: PlayerConnection, playerId: PlayerId, name: String) {
        connections[playerId] = connection
        broadcastPublic(engine.addPlayer(playerId, name))
    }

    fun leave(playerId: PlayerId) {
        connections.remove(playerId)
        broadcastPublic(engine.removePlayer(playerId))
    }

    fun startGame() {
        // RoleAssigned events are PRIVATE — route only to the assigned player.
        engine.startGame().forEach { event ->
            when (event) {
                is GameEvent.RoleAssigned -> sendTo(event.playerId, event)
                else -> broadcastPublic(event)
            }
        }
    }

    fun submitNightAction(actorId: PlayerId, targetId: PlayerId) {
        engine.submitNightAction(actorId, targetId)
        // Night actions are acknowledged privately; resolution is broadcast later via resolveNight().
    }

    fun resolveNightAndAdvance() {
        engine.resolveNight().forEach { event -> routeNightEvent(event) }
        maybeEndGameOr { engine.beginDay() }
    }

    private fun routeNightEvent(event: GameEvent) {
        when (event) {
            is GameEvent.PlayerProtected -> Unit // only the doctor needs this — omitted here for brevity, wire via actorId if tracked
            is GameEvent.InvestigationResult -> sendTo(event.investigatorId, event)
            is GameEvent.PlayerTargeted -> Unit // private, not broadcast — mafia already knows who they targeted client-side
            is GameEvent.PlayerEliminated -> broadcastPublic(event) // public: town wakes up to a body
            else -> broadcastPublic(event)
        }
    }

    fun castVote(voterId: PlayerId, targetId: PlayerId?) {
        engine.castVote(voterId, targetId) // vote receipts are typically private; tally broadcast on close
    }

    fun closeVotingAndAdvance() {
        engine.closeVoting().forEach { broadcastPublic(it) }
        maybeEndGameOr { engine.beginNight() }
    }

    private fun maybeEndGameOr(continueWith: () -> GameEvent) {
        val ended = engine.checkWinCondition()
        if (ended != null) {
            broadcastPublic(ended)
        } else {
            broadcastPublic(continueWith())
        }
    }

    private fun broadcastPublic(event: GameEvent) {
        connections.values.forEach { it.send(event) }
    }

    private fun sendTo(playerId: PlayerId, event: GameEvent) {
        connections[playerId]?.send(event)
    }
}

/** Abstraction over the actual transport (WebSocketSession) so Room stays testable without a real socket. */
fun interface PlayerConnection {
    fun send(event: GameEvent)
}
