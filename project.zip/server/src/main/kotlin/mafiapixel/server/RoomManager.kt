package mafiapixel.server

import mafiapixel.engine.GameSettings
import kotlin.random.Random

object RoomManager {
    private val rooms = mutableMapOf<String, Room>()
    private val codeChars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789" // no 0/O/1/I ambiguity

    fun createRoom(settings: GameSettings = GameSettings()): Room {
        var code: String
        do { code = (1..5).map { codeChars.random() }.joinToString("") } while (rooms.containsKey(code))
        val room = Room(code, settings)
        rooms[code] = room
        return room
    }

    fun get(code: String): Room? = rooms[code.uppercase()]

    fun close(code: String) { rooms.remove(code.uppercase()) }
}

private fun String.random(): Char = this[Random.nextInt(length)]
