plugins {
    id("com.android.application")
    kotlin("android")
}

val gdxVersion = "1.12.1"
val natives by configurations.creating

android {
    namespace = "mafiapixel.android"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.mafiapixel.game"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "0.1"
    }
    sourceSets["main"].jniLibs.srcDir("libs")
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(project(":core"))
    implementation("com.badlogicgames.gdx:gdx:$gdxVersion")
    implementation("com.badlogicgames.gdx:gdx-backend-android:$gdxVersion")
    natives("com.badlogicgames.gdx:gdx-platform:$gdxVersion:natives-armeabi-v7a")
    natives("com.badlogicgames.gdx:gdx-platform:$gdxVersion:natives-arm64-v8a")
}

tasks.register("copyAndroidNatives") {
    doFirst {
        natives.files.forEach { jar ->
            val abi = when {
                jar.name.endsWith("natives-armeabi-v7a.jar") -> "armeabi-v7a"
                jar.name.endsWith("natives-arm64-v8a.jar") -> "arm64-v8a"
                else -> null
            }
            if (abi != null) {
                val out = file("libs/$abi")
                out.mkdirs()
                project.copy {
                    from(zipTree(jar))
                    into(out)
                    include("*.so")
                }
            }
        }
    }
}

tasks.configureEach {
    if (name.contains("merge") && name.contains("JniLibFolders")) dependsOn("copyAndroidNatives")
}
