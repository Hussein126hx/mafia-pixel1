package mafiapixel.engine

/** High-level alignment. Every Role belongs to exactly one Team. */
enum class Team { TOWN, MAFIA, NEUTRAL }

/** When (if ever) a role acts during the Night phase. */
enum class NightActionType {
    NONE,           // Citizen, etc. — no night ability
    KILL,           // Mafia Member / Boss
    INVESTIGATE,    // Detective / Mafia Investigator
    PROTECT,        // Doctor
    GUARD,          // Guard (blocks a target's visitors / protects a spot)
    INFORM          // Informant — passive/one-shot info reveal
}

/**
 * A single role definition. Roles are data, not hardcoded switch-cases,
 * so adding a new role never requires touching NightSystem/DaySystem directly —
 * only registering its resolution logic in NightSystem.actionResolvers.
 */
data class Role(
    val id: String,
    val displayName: String,
    val team: Team,
    val nightAction: NightActionType,
    val actsEveryNight: Boolean = true,
    val revealsTeamToAllies: Boolean = false, // e.g. Mafia sees each other
    val description: String = ""
) {
    companion object {
        val CITIZEN = Role("citizen", "Citizen", Team.TOWN, NightActionType.NONE)
        val DETECTIVE = Role("detective", "Detective", Team.TOWN, NightActionType.INVESTIGATE)
        val DOCTOR = Role("doctor", "Doctor", Team.TOWN, NightActionType.PROTECT)
        val GUARD = Role("guard", "Guard", Team.TOWN, NightActionType.GUARD)
        val INFORMANT_TOWN = Role("informant_town", "Informant", Team.TOWN, NightActionType.INFORM, actsEveryNight = false)

        val MAFIA_MEMBER = Role("mafia_member", "Mafia Member", Team.MAFIA, NightActionType.KILL, revealsTeamToAllies = true)
        val MAFIA_BOSS = Role("mafia_boss", "Mafia Boss", Team.MAFIA, NightActionType.KILL, revealsTeamToAllies = true)
        val MAFIA_INFORMANT = Role("mafia_informant", "Mafia Informant", Team.MAFIA, NightActionType.INFORM, revealsTeamToAllies = true)
        val MAFIA_INVESTIGATOR = Role("mafia_investigator", "Mafia Investigator", Team.MAFIA, NightActionType.INVESTIGATE, revealsTeamToAllies = true)

        val SURVIVOR = Role("survivor", "Survivor", Team.NEUTRAL, NightActionType.NONE)
        val REVENGE_SEEKER = Role("revenge_seeker", "Revenge-Seeker", Team.NEUTRAL, NightActionType.KILL, actsEveryNight = false)
        val TRICKSTER = Role("trickster", "Trickster", Team.NEUTRAL, NightActionType.NONE)
        val INDEPENDENT_INVESTIGATOR = Role("independent_investigator", "Independent Investigator", Team.NEUTRAL, NightActionType.INVESTIGATE)

        val ALL_BUILTIN = listOf(
            CITIZEN, DETECTIVE, DOCTOR, GUARD, INFORMANT_TOWN,
            MAFIA_MEMBER, MAFIA_BOSS, MAFIA_INFORMANT, MAFIA_INVESTIGATOR,
            SURVIVOR, REVENGE_SEEKER, TRICKSTER, INDEPENDENT_INVESTIGATOR
        )
    }
}

/**
 * Defines how many of each role a match gets, tiered by lobby size.
 * The host can later override this pool via GameSettings.customRolePool.
 */
object RolePoolTiers {

    data class Tier(val minPlayers: Int, val maxPlayers: Int, val build: (Int) -> List<Role>)

    val tiers = listOf(
        Tier(5, 7) { n -> basic(n) },
        Tier(8, 12) { n -> intermediate(n) },
        Tier(13, 20) { n -> advanced(n) },
        Tier(21, 35) { n -> complex(n) },
        Tier(36, 50) { n -> largeScale(n) }
    )

    fun forPlayerCount(n: Int): List<Role> {
        val tier = tiers.firstOrNull { n in it.minPlayers..it.maxPlayers }
            ?: tiers.last() // clamp above 50 to large-scale ratios
        return tier.build(n)
    }

    private fun mafiaCount(n: Int): Int = (n / 3.5).toInt().coerceAtLeast(1)

    private fun basic(n: Int): List<Role> {
        val mafia = mafiaCount(n).coerceAtMost(2)
        val roles = mutableListOf<Role>()
        repeat(mafia) { roles += Role.MAFIA_MEMBER }
        roles += Role.DETECTIVE
        roles += Role.DOCTOR
        fillCitizens(roles, n)
        return roles
    }

    private fun intermediate(n: Int): List<Role> {
        val mafia = mafiaCount(n)
        val roles = mutableListOf<Role>()
        roles += Role.MAFIA_BOSS
        repeat((mafia - 1).coerceAtLeast(1)) { roles += Role.MAFIA_MEMBER }
        roles += Role.DETECTIVE
        roles += Role.DOCTOR
        roles += Role.GUARD
        roles += Role.SURVIVOR
        fillCitizens(roles, n)
        return roles
    }

    private fun advanced(n: Int): List<Role> {
        val mafia = mafiaCount(n)
        val roles = mutableListOf<Role>()
        roles += Role.MAFIA_BOSS
        roles += Role.MAFIA_INFORMANT
        repeat((mafia - 2).coerceAtLeast(1)) { roles += Role.MAFIA_MEMBER }
        roles += Role.DETECTIVE
        roles += Role.DOCTOR
        roles += Role.GUARD
        roles += Role.INFORMANT_TOWN
        roles += Role.SURVIVOR
        roles += Role.REVENGE_SEEKER
        fillCitizens(roles, n)
        return roles
    }

    private fun complex(n: Int): List<Role> {
        val mafia = mafiaCount(n)
        val roles = mutableListOf<Role>()
        roles += Role.MAFIA_BOSS
        roles += Role.MAFIA_INFORMANT
        roles += Role.MAFIA_INVESTIGATOR
        repeat((mafia - 3).coerceAtLeast(2)) { roles += Role.MAFIA_MEMBER }
        roles += Role.DETECTIVE
        roles += Role.DOCTOR
        roles += Role.GUARD
        roles += Role.INFORMANT_TOWN
        roles += Role.SURVIVOR
        roles += Role.REVENGE_SEEKER
        roles += Role.TRICKSTER
        roles += Role.INDEPENDENT_INVESTIGATOR
        fillCitizens(roles, n)
        return roles
    }

    private fun largeScale(n: Int): List<Role> {
        // Same shape as `complex`, scaled: more mafia + more duplicated town specials.
        val mafia = mafiaCount(n)
        val roles = mutableListOf<Role>()
        roles += Role.MAFIA_BOSS
        roles += Role.MAFIA_INFORMANT
        roles += Role.MAFIA_INVESTIGATOR
        repeat((mafia - 3).coerceAtLeast(3)) { roles += Role.MAFIA_MEMBER }
        roles += Role.DETECTIVE
        roles += Role.DETECTIVE
        roles += Role.DOCTOR
        roles += Role.DOCTOR
        roles += Role.GUARD
        roles += Role.INFORMANT_TOWN
        roles += Role.SURVIVOR
        roles += Role.REVENGE_SEEKER
        roles += Role.TRICKSTER
        roles += Role.INDEPENDENT_INVESTIGATOR
        fillCitizens(roles, n)
        return roles
    }

    private fun fillCitizens(roles: MutableList<Role>, n: Int) {
        while (roles.size < n) roles += Role.CITIZEN
        while (roles.size > n) roles.removeAt(roles.size - 1) // safety clamp
    }
}
