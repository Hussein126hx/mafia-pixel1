package mafiapixel.engine

class RoleManager {

    /** Deterministic given the same [rng] seed — useful for tests and replay/debug. */
    fun distribute(players: List<Player>, settings: GameSettings, rng: (Int) -> Int): Map<PlayerId, Role> {
        val pool = (settings.customRolePool ?: RolePoolTiers.forPlayerCount(players.size)).toMutableList()
        require(pool.size == players.size) {
            "Role pool size (${pool.size}) must match player count (${players.size})"
        }
        val shuffled = shuffle(pool, rng)
        return players.mapIndexed { i, p -> p.id to shuffled[i] }.toMap()
    }

    /** Fisher-Yates using an injected rng so server & client-side test tools can share logic deterministically. */
    private fun <T> shuffle(list: MutableList<T>, rng: (Int) -> Int): List<T> {
        for (i in list.indices.reversed()) {
            val j = rng(i + 1)
            val tmp = list[i]; list[i] = list[j]; list[j] = tmp
        }
        return list
    }

    /** Which mafia teammates a given player is allowed to see, per `revealsTeamToAllies`. */
    fun mafiaTeammatesOf(playerId: PlayerId, roster: Map<PlayerId, Role>): List<PlayerId> {
        val self = roster[playerId] ?: return emptyList()
        if (!self.revealsTeamToAllies || self.team != Team.MAFIA) return emptyList()
        return roster.filter { it.key != playerId && it.value.team == Team.MAFIA && it.value.revealsTeamToAllies }.keys.toList()
    }
}
