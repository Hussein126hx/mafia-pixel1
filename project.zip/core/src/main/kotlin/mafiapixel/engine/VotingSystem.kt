package mafiapixel.engine

enum class TieRule { NO_ELIMINATION, RANDOM_AMONG_TIED, REVOTE }

class VotingSystem(private val tieRule: TieRule = TieRule.NO_ELIMINATION) {

    private val votes = mutableMapOf<PlayerId, PlayerId?>() // voterId -> targetId (null = abstain)

    fun castVote(voterId: PlayerId, targetId: PlayerId?): GameEvent {
        votes[voterId] = targetId
        return GameEvent.VoteCast(voterId, targetId)
    }

    fun reset() = votes.clear()

    /** Tally votes and resolve to a single elimination target (or null). */
    fun close(alivePlayers: Set<PlayerId>, rng: (Int) -> Int): GameEvent.VotingClosed {
        val tally = mutableMapOf<PlayerId, Int>()
        votes.filterKeys { it in alivePlayers }.values.forEach { target ->
            if (target != null) tally[target] = (tally[target] ?: 0) + 1
        }
        val maxVotes = tally.values.maxOrNull() ?: 0
        val leaders = tally.filterValues { it == maxVotes }.keys.toList()

        val eliminated: PlayerId? = when {
            maxVotes == 0 -> null
            leaders.size == 1 -> leaders.first()
            else -> when (tieRule) {
                TieRule.NO_ELIMINATION -> null
                TieRule.RANDOM_AMONG_TIED -> leaders[rng(leaders.size)]
                TieRule.REVOTE -> null // caller (GameEngine) sees leaders.size > 1 and re-opens voting among `leaders`
            }
        }
        return GameEvent.VotingClosed(tally.toMap(), eliminated)
    }
}
