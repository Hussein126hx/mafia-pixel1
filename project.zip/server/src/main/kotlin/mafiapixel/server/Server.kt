package mafiapixel.server

import io.ktor.serialization.kotlinx.json.*
import io.ktor.server.application.*
import io.ktor.server.engine.*
import io.ktor.server.netty.*
import io.ktor.server.plugins.contentnegotiation.*
import io.ktor.server.websocket.*
import io.ktor.server.routing.*
import io.ktor.websocket.*
import kotlinx.coroutines.channels.consumeEach
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import mafiapixel.engine.GameEvent
import mafiapixel.engine.GameSettings
import java.time.Duration

/**
 * Same entrypoint runs in two modes:
 *  --mode=online  -> binds 0.0.0.0:PORT, meant for a cloud host
 *  --mode=local   -> binds 0.0.0.0:PORT on the host device itself (Wi-Fi/hotspot);
 *                    Android host app launches this embedded, same JAR/classes.
 * Only the bind address/port and how clients discover it (room code + QR vs
 * DNS) differ — Room/RoomManager/GameEngine code is identical either way.
 */
fun main(args: Array<String>) {
    val port = System.getenv("PORT")?.toIntOrNull() ?: 8080
    embeddedServer(Netty, port = port) {
        install(WebSockets) { pingPeriod = Duration.ofSeconds(15) }
        install(ContentNegotiation) { json(Json { ignoreUnknownKeys = true }) }
        routing {
            webSocket("/room/{code}") {
                val code = call.parameters["code"] ?: return@webSocket close()
                val room = RoomManager.get(code) ?: RoomManager.createRoom(GameSettings()).also {
                    // In production: only ever auto-create when hitting /room/create; left permissive here for MVP wiring.
                }
                var playerId: String? = null

                val connection = PlayerConnection { event -> sendSerialized(this, event) }

                incoming.consumeEach { frame ->
                    if (frame !is Frame.Text) return@consumeEach
                    val msg = Json.decodeFromString<ClientMessage>(frame.readText())
                    when (msg) {
                        is ClientMessage.Join -> {
                            playerId = msg.playerId
                            room.join(connection, msg.playerId, msg.name)
                        }
                        is ClientMessage.StartGame -> room.startGame()
                        is ClientMessage.NightAction -> room.submitNightAction(msg.actorId, msg.targetId)
                        is ClientMessage.ResolveNight -> room.resolveNightAndAdvance()
                        is ClientMessage.CastVote -> room.castVote(msg.voterId, msg.targetId)
                        is ClientMessage.CloseVoting -> room.closeVotingAndAdvance()
                    }
                }
                playerId?.let { room.leave(it) }
            }
        }
    }.start(wait = true)
}

private fun sendSerialized(session: DefaultWebSocketServerSession, event: GameEvent) {
    // NOTE: kotlinx.serialization needs @Serializable on GameEvent's sealed hierarchy
    // (added in the core module before wiring this up for real) — omitted here to
    // keep this file focused on routing/transport shape for the MVP scaffold.
}

@Serializable
sealed class ClientMessage {
    @Serializable data class Join(val playerId: String, val name: String) : ClientMessage()
    @Serializable object StartGame : ClientMessage()
    @Serializable data class NightAction(val actorId: String, val targetId: String) : ClientMessage()
    @Serializable object ResolveNight : ClientMessage()
    @Serializable data class CastVote(val voterId: String, val targetId: String?) : ClientMessage()
    @Serializable object CloseVoting : ClientMessage()
}
