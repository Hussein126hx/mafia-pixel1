# MAFIA PIXEL — Engineering Scaffold

## Tech decisions (locked in for speed — see rationale)

| Layer | Choice | Why |
|---|---|---|
| Shared game logic | **Kotlin** (`core` module, pure JVM/Kotlin, zero UI/network deps) | One language across client+server; the exact "GameEngine independent of UI/network" requirement from the spec. |
| Client rendering | **libGDX** | Mature 2D engine, first-class pixel-art rendering, particles, shaders, parallax, Android-native, scales effects by device tier. |
| Server (authoritative) | **Ktor + WebSockets** (Kotlin) | Same JVM/Kotlin as `core` — the server literally imports the `core` module directly, no protocol translation layer. |
| Online vs Local/Hotspot | **Same server code, different bind address** | Cloud: Ktor binds a public port. Local/Hotspot: the *host's own Android device* runs the identical Ktor server in-process; other phones connect to the host's local IP. Zero engine/logic duplication. |
| Serialization | kotlinx.serialization (JSON over WebSocket) | Simple, debuggable, fast enough for a text/vote/night-action protocol (not sending video/audio). |

## Module map

```
mafia-pixel/
├── core/           Pure Kotlin. GameEngine, GameState, RoleManager, NightSystem,
│                   VotingSystem, VictorySystem, GameEvent. No Android, no network imports.
│                   -> This is the module both server AND client depend on.
├── server/         Ktor app. Room = one GameEngine instance + connected sockets.
│                   RoomManager = room codes + lookup. Filters private events
│                   (RoleAssigned, InvestigationResult, ...) so they only ever
│                   reach the correct player — never broadcast raw.
└── android/        NOT YET SCAFFOLDED — Phase 3+ (libGDX client, Lobby UI,
                    Pixel City environment, cinematic transitions).
```

## What's actually built right now (this pass)

- `Role.kt` — Team/Role/NightActionType definitions + `RolePoolTiers`, which
  dynamically builds a role list per player-count bracket (5–7, 8–12, 13–20,
  21–35, 36–50), matching spec section 8. Host override via `GameSettings.customRolePool`.
- `Types.kt` — `Player`, `GamePhase` (the 12-state machine from section 19),
  `GameSettings`, and the full `GameEvent` sealed hierarchy (section 20).
- `RoleManager.kt` — seeded Fisher-Yates role distribution + "who are my mafia
  teammates" visibility rule.
- `NightSystem.kt` — priority-ordered resolution (Guard → Protect → Kill →
  Investigate → Inform) so adding a new night role never touches other systems.
- `VotingSystem.kt` — tally + configurable tie rule (no-elim / random / revote).
- `VictorySystem.kt` — modular `VictoryCondition` list; Town/Mafia conditions
  wired, Neutral solo-win conditions are a one-line addition via `registerCondition`.
- `GameEngine.kt` — the actual state machine wiring all of the above through
  the full LOBBY → ... → GAME_END loop from spec section 6, with private vs.
  public event separation baked in (never leaks secret info by construction).
- `Room.kt` / `RoomManager.kt` / `Server.kt` — Ktor scaffold showing exactly
  where sockets attach to the engine and how private events get routed
  per-recipient. **`Server.kt`'s serialization wiring is a stub** — the last
  step of Phase 7 is adding `@Serializable` to `GameEvent` and finishing
  `sendSerialized`.

## Explicitly NOT built yet (by design — see Phase plan)

- Android/libGDX client (rendering, pixel art, parallax, cinematics) — Phase 3+.
- Persistence/reconnection replay of missed state.
- Local Network/Hotspot bootstrapping code (mDNS/manual-IP discovery UI).
- Real crypto/auth on room join (MVP trusts client-supplied playerId).

## Immediate next steps, in order

1. Finish `GameEvent` serialization + wire `sendSerialized` for real.
2. Unit-test `GameEngine` end-to-end with a scripted 7-player match (no UI needed —
   this validates the entire rules engine before touching graphics).
3. Scaffold `android/` as a libGDX project depending on `core`; build the
   MVP screens in spec order: Main Menu → Create/Join → Lobby → Role Reveal.
4. Wire the Ktor client (WebSocket) into the Android app, pointed at
   `ws://<host-ip>:8080/room/<code>` — same code path for online (domain)
   and local (LAN IP).

This scaffold intentionally targets the **5–15 player MVP** first, per spec
section 35 — the role tiers for 16–50 already exist in `RolePoolTiers` so
scaling up later is a balance-tuning exercise, not a rewrite.
