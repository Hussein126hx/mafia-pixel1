package mafiapixel.engine

/** One submitted night action, before resolution. */
data class NightAction(val actorId: PlayerId, val targetId: PlayerId, val type: NightActionType)

/**
 * Resolution order matters: GUARD/PROTECT must resolve before KILL,
 * INVESTIGATE can run independently, INFORM is passive/instant.
 * Adding a new night-acting role only means adding it to a priority bucket here —
 * no other system needs to change.
 */
class NightSystem {

    private val priority = listOf(
        NightActionType.GUARD,
        NightActionType.PROTECT,
        NightActionType.KILL,
        NightActionType.INVESTIGATE,
        NightActionType.INFORM
    )

    /**
     * Resolves a night's submitted actions into public/private events.
     * Only one action per actor is honored (the last one submitted wins) —
     * enforcement of "one action per role per night" belongs to the caller (GameEngine)
     * which owns the submission window.
     */
    fun resolve(
        roster: Map<PlayerId, Role>,
        players: Map<PlayerId, Player>,
        submitted: List<NightAction>
    ): List<GameEvent> {
        val events = mutableListOf<GameEvent>()
        val protectedIds = mutableSetOf<PlayerId>()
        val guardedIds = mutableSetOf<PlayerId>()

        val byType = submitted.groupBy { it.type }

        for (type in priority) {
            val actions = byType[type] ?: continue
            when (type) {
                NightActionType.PROTECT -> actions.forEach {
                    protectedIds += it.targetId
                    events += GameEvent.PlayerProtected(it.targetId)
                }
                NightActionType.GUARD -> actions.forEach { guardedIds += it.targetId }
                NightActionType.KILL -> actions.forEach { action ->
                    events += GameEvent.PlayerTargeted(action.actorId, action.targetId, type)
                    val blocked = action.targetId in protectedIds || action.targetId in guardedIds
                    if (!blocked) {
                        val victim = players[action.targetId]
                        if (victim != null && victim.isAlive) {
                            victim.state = PlayerConnState.DEAD
                            events += GameEvent.PlayerEliminated(
                                action.targetId,
                                EliminationCause.MAFIA_KILL,
                                revealedRole = roster[action.targetId]
                            )
                        }
                    }
                }
                NightActionType.INVESTIGATE -> actions.forEach { action ->
                    val targetTeam = roster[action.targetId]?.team
                    if (targetTeam != null) {
                        events += GameEvent.InvestigationResult(action.actorId, action.targetId, targetTeam)
                    }
                }
                NightActionType.INFORM -> actions.forEach {
                    events += GameEvent.PlayerTargeted(it.actorId, it.targetId, type)
                }
                NightActionType.NONE -> Unit
            }
        }
        return events
    }
}
